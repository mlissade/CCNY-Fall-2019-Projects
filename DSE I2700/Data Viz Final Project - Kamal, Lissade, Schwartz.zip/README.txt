To run the interactive visualization, must use Python via Jupyter Notebook
and the following libraries must also be installed for the notebook:
	* pandas
	* numpy
	* datetime
	* bokeh